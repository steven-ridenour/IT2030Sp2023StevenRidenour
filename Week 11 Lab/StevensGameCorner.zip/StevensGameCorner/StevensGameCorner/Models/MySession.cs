﻿namespace StevensGameCorner.Models
{
    public class MySession
    {
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public String Course { get; set; }
        public int FavNum { get; set; }

    }
}
